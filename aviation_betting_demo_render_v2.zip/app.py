import os
from decimal import Decimal
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-secret-key")

# IMPORTANT FOR RENDER:
# Set DATABASE_URL to a managed PostgreSQL database.
# SQLite is only a local fallback.
database_url = os.environ.get("DATABASE_URL", "sqlite:///aviation_demo.db")
if database_url.startswith("postgres://"):
    database_url = database_url.replace("postgres://", "postgresql://", 1)
app.config["SQLALCHEMY_DATABASE_URI"] = database_url
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)

MIN_STAKE = Decimal("10.00")

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    balance = db.Column(db.Numeric(12, 2), nullable=False, default=Decimal("1000.00"))
    is_admin = db.Column(db.Boolean, nullable=False, default=False)
    bets = db.relationship("Bet", backref="user", lazy=True)

class Bet(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    flight = db.Column(db.String(120), nullable=False)
    selection = db.Column(db.String(120), nullable=False)
    stake = db.Column(db.Numeric(12, 2), nullable=False)
    multiplier = db.Column(db.Numeric(8, 2), nullable=False)
    potential_win = db.Column(db.Numeric(12, 2), nullable=False)
    status = db.Column(db.String(20), nullable=False, default="PENDING")
    created_at = db.Column(db.DateTime, server_default=db.func.now(), nullable=False)

class DemoRound(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    flight = db.Column(db.String(120), nullable=False)
    status = db.Column(db.String(20), nullable=False, default="OPEN")
    odd_up = db.Column(db.Numeric(8, 2), nullable=False, default=Decimal("1.90"))
    odd_down = db.Column(db.Numeric(8, 2), nullable=False, default=Decimal("1.90"))

def current_user():
    uid = session.get("user_id")
    return db.session.get(User, uid) if uid else None

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user():
            flash("Please log in first.", "warning")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        user = current_user()
        if not user or not user.is_admin:
            flash("Admin access required.", "danger")
            return redirect(url_for("index"))
        return fn(*args, **kwargs)
    return wrapper

@app.context_processor
def inject_user():
    return {"current_user": current_user(), "MIN_STAKE": MIN_STAKE}

@app.route("/")
def index():
    rounds = DemoRound.query.order_by(DemoRound.id.desc()).all()
    return render_template("index.html", rounds=rounds)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if len(username) < 3 or len(password) < 6:
            flash("Username must be 3+ characters and password 6+ characters.", "danger")
            return render_template("register.html")
        if User.query.filter_by(username=username).first():
            flash("Username already exists.", "danger")
            return render_template("register.html")
        user = User(username=username, password_hash=generate_password_hash(password),
                    balance=Decimal("1000.00"))
        db.session.add(user)
        db.session.commit()
        flash("Account created. You have 1,000 virtual credits.", "success")
        return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            session["user_id"] = user.id
            return redirect(url_for("index"))
        flash("Invalid username or password.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/bet", methods=["POST"])
@login_required
def place_bet():
    user = current_user()
    flight = request.form.get("flight", "").strip()
    selection = request.form.get("selection", "").strip()
    try:
        stake = Decimal(request.form.get("stake", "0"))
    except Exception:
        stake = Decimal("0")

    try:
        multiplier = Decimal(request.form.get("multiplier", "1.90"))
    except Exception:
        multiplier = Decimal("1.90")

    if not flight or not selection:
        flash("Choose a flight and selection.", "danger")
        return redirect(url_for("index"))
    if stake < MIN_STAKE:
        flash("Minimum stake is 10 virtual credits.", "danger")
        return redirect(url_for("index"))
    if stake > user.balance:
        flash("Insufficient virtual balance.", "danger")
        return redirect(url_for("index"))

    potential = (stake * multiplier).quantize(Decimal("0.01"))
    user.balance = (Decimal(user.balance) - stake).quantize(Decimal("0.01"))
    bet = Bet(user_id=user.id, flight=flight, selection=selection,
              stake=stake, multiplier=multiplier, potential_win=potential)
    db.session.add(bet)
    db.session.commit()

    flash(f"Bet #{bet.id} placed for {stake:.2f} virtual credits.", "success")
    return redirect(url_for("my_bets"))

@app.route("/bets")
@login_required
def my_bets():
    bets = Bet.query.filter_by(user_id=current_user().id).order_by(Bet.id.desc()).all()
    return render_template("bets.html", bets=bets)

@app.route("/admin")
@admin_required
def admin():
    users = User.query.order_by(User.id.desc()).all()
    bets = Bet.query.order_by(Bet.id.desc()).limit(100).all()
    return render_template("admin.html", users=users, bets=bets)

@app.route("/admin/seed", methods=["POST"])
@admin_required
def seed_rounds():
    defaults = [
        ("AL-101 • Nairobi → Mombasa", "1.90", "1.90"),
        ("AL-202 • Nairobi → Kisumu", "2.10", "1.75"),
        ("AL-303 • Mombasa → Nairobi", "1.80", "2.05"),
        ("AL-404 • Kisumu → Nairobi", "2.20", "1.65"),
    ]
    for flight, up, down in defaults:
        db.session.add(DemoRound(flight=flight, odd_up=Decimal(up), odd_down=Decimal(down)))
    db.session.commit()
    flash("Demo flight rounds added.", "success")
    return redirect(url_for("admin"))

@app.route("/admin/bet/<int:bet_id>/<status>", methods=["POST"])
@admin_required
def settle_bet(bet_id, status):
    if status not in {"WON", "LOST", "CANCELLED"}:
        flash("Invalid status.", "danger")
        return redirect(url_for("admin"))

    bet = db.session.get(Bet, bet_id)
    if not bet:
        flash("Bet not found.", "danger")
        return redirect(url_for("admin"))
    if bet.status != "PENDING":
        flash("That bet has already been settled.", "warning")
        return redirect(url_for("admin"))

    bet.status = status
    if status == "WON":
        bet.user.balance = (Decimal(bet.user.balance) + Decimal(bet.potential_win)).quantize(Decimal("0.01"))
    elif status == "CANCELLED":
        bet.user.balance = (Decimal(bet.user.balance) + Decimal(bet.stake)).quantize(Decimal("0.01"))

    db.session.commit()
    flash(f"Bet #{bet.id} marked {status}.", "success")
    return redirect(url_for("admin"))

@app.cli.command("init-db")
def init_db():
    db.create_all()
    if not User.query.filter_by(username="admin").first():
        admin = User(username="admin",
                     password_hash=generate_password_hash("ChangeMe123!"),
                     balance=Decimal("0.00"), is_admin=True)
        db.session.add(admin)
    if DemoRound.query.count() == 0:
        for flight, up, down in [
            ("AL-101 • Nairobi → Mombasa", "1.90", "1.90"),
            ("AL-202 • Nairobi → Kisumu", "2.10", "1.75"),
            ("AL-303 • Mombasa → Nairobi", "1.80", "2.05"),
            ("AL-404 • Kisumu → Nairobi", "2.20", "1.65"),
        ]:
            db.session.add(DemoRound(flight=flight, odd_up=Decimal(up), odd_down=Decimal(down)))
    db.session.commit()
    print("Database initialized. Admin username: admin / password: ChangeMe123!")

with app.app_context():
    db.create_all()
    # Create a demo admin and demo flight rounds on first startup.
    # Set ADMIN_USERNAME and ADMIN_PASSWORD in Render before exposing the app publicly.
    admin_username = os.environ.get("ADMIN_USERNAME", "admin")
    admin_password = os.environ.get("ADMIN_PASSWORD", "ChangeMe123!")
    if not User.query.filter_by(username=admin_username).first():
        db.session.add(User(
            username=admin_username,
            password_hash=generate_password_hash(admin_password),
            balance=Decimal("0.00"),
            is_admin=True
        ))
    if DemoRound.query.count() == 0:
        for flight, up, down in [
            ("AL-101 • Nairobi → Mombasa", "1.90", "1.90"),
            ("AL-202 • Nairobi → Kisumu", "2.10", "1.75"),
            ("AL-303 • Mombasa → Nairobi", "1.80", "2.05"),
            ("AL-404 • Kisumu → Nairobi", "2.20", "1.65"),
        ]:
            db.session.add(DemoRound(flight=flight, odd_up=Decimal(up), odd_down=Decimal(down)))
    db.session.commit()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")))
