# Aviation Betting Demo

A Flask aviation-themed **play-money betting demo**.

## Important
This project uses virtual credits only. It does not process deposits, withdrawals, mobile-money payments, or real-money wagers. Before offering real-money gambling, obtain the required licenses and implement the applicable age, identity, responsible-gambling, payment, security, audit, tax, and regulatory controls.

## Features
- Registration and login
- 1,000 virtual credits for each new account
- Minimum stake: 10 virtual credits
- Aviation-style flight selections
- Potential-win calculation
- Personal bet history
- Admin dashboard
- Admin bet settlement
- PostgreSQL support for persistent production data
- SQLite fallback for local testing
- Render configuration

## Run locally

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
flask --app app init-db
python app.py
```

Open http://127.0.0.1:5000

## Admin
Admin credentials are controlled by environment variables:
- `ADMIN_USERNAME`
- `ADMIN_PASSWORD`

If unset, the demo defaults are `admin` / `ChangeMe123!`. Set both on Render before making the site public.

## Render
The included `render.yaml` creates a web service and a PostgreSQL database. Commit all files, then connect the GitHub repository to Render.

The PostgreSQL database is important because a normal Render web-service filesystem should not be treated as permanent storage for business records.

## GitHub structure

```text
Aviation-ltd/
├── app.py
├── requirements.txt
├── Procfile
├── render.yaml
├── .gitignore
├── README.md
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── login.html
│   ├── register.html
│   ├── bets.html
│   └── admin.html
└── static/
    └── style.css
```
