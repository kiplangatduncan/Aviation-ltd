
from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3, os, secrets
from functools import wraps
from datetime import datetime

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "aviation.db")

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", secrets.token_hex(32))

def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    conn.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        balance INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS bets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        stake INTEGER NOT NULL,
        multiplier REAL NOT NULL,
        payout INTEGER NOT NULL,
        status TEXT NOT NULL,
        created_at TEXT NOT NULL
    )""")
    conn.commit()
    return conn

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper

@app.route("/")
def index():
    return render_template("index.html", user=session.get("username"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"].strip()
        password = request.form["password"]
        if not username or not password:
            flash("Username and password are required.")
            return redirect(url_for("register"))
        conn = db()
        try:
            conn.execute("INSERT INTO users(username,password,created_at) VALUES(?,?,?)",
                         (username, password, datetime.utcnow().isoformat()))
            conn.commit()
            flash("Account created. You can now log in.")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("That username already exists.")
        finally:
            conn.close()
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        conn = db()
        user = conn.execute("SELECT * FROM users WHERE username=? AND password=?",
                            (request.form["username"].strip(), request.form["password"])).fetchone()
        conn.close()
        if user:
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            return redirect(url_for("game"))
        flash("Invalid username or password.")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/game", methods=["GET", "POST"])
@login_required
def game():
    conn = db()
    user = conn.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
    if request.method == "POST":
        try:
            stake = int(request.form.get("stake", "0"))
            multiplier = float(request.form.get("multiplier", "1.00"))
        except ValueError:
            stake, multiplier = 0, 1.0

        if stake < 10:
            flash("Minimum stake is KSh 10.")
        elif stake > user["balance"]:
            flash("Insufficient balance. This demo does not process real deposits.")
        else:
            payout = int(stake * multiplier)
            conn.execute("UPDATE users SET balance=balance-? WHERE id=?", (stake, user["id"]))
            conn.execute("""INSERT INTO bets(user_id,stake,multiplier,payout,status,created_at)
                            VALUES(?,?,?,?,?,?)""",
                         (user["id"], stake, multiplier, payout, "DEMO",
                          datetime.utcnow().isoformat()))
            conn.commit()
            flash(f"Demo bet recorded: KSh {stake} at {multiplier:.2f}x.")
    user = conn.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
    bets = conn.execute("SELECT * FROM bets WHERE user_id=? ORDER BY id DESC LIMIT 20",
                        (session["user_id"],)).fetchall()
    conn.close()
    return render_template("game.html", user=user, bets=bets)

@app.route("/demo-credit", methods=["POST"])
@login_required
def demo_credit():
    amount = int(request.form.get("amount", "0"))
    if 0 < amount <= 100000:
        conn = db()
        conn.execute("UPDATE users SET balance=balance+? WHERE id=?", (amount, session["user_id"]))
        conn.commit()
        conn.close()
        flash(f"Demo credit of KSh {amount} added.")
    return redirect(url_for("game"))

if __name__ == "__main__":
    db().close()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
