AVIATION BET DEMO
=================
Files:
- app.py
- requirements.txt
- templates/
- static/

Run locally:
1. python -m venv venv
2. activate the venv
3. pip install -r requirements.txt
4. python app.py
5. Open http://127.0.0.1:5000

IMPORTANT:
This is a DEMO interface. It does not process real money, deposits,
withdrawals, or real gambling. The database is SQLite and stores demo
accounts and bet records locally in aviation.db.
For a real-money Kenyan betting service, obtain the required licensing
and implement regulated payment, KYC/AML, responsible-gambling,
security, audit and game-integrity systems before going live.
