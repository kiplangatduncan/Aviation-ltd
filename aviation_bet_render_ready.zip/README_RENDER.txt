RENDER SETUP
1. Upload this project to GitHub.
2. In Render choose New -> Web Service and select the repository.
3. Build Command: pip install -r requirements.txt
4. Start Command: gunicorn app:app
5. Deploy.

The included render.yaml can also be used with Render Blueprint deployment.

DATABASE:
This starter uses SQLite for demonstration. For permanent production records,
use managed PostgreSQL. Do not rely on an ordinary Render web-service filesystem
for permanent betting records.

REAL-MONEY WARNING:
This project is a demo and does not process real deposits, withdrawals or
real-money gambling. A real-money Kenyan service requires appropriate
licensing/regulatory compliance plus secure payments, game integrity, audit
logging, KYC/AML and responsible-gambling controls.
