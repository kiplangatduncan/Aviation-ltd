from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3, os, secrets
from functools import wraps
from datetime import datetime

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "aviation.db")
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", secrets.token_hex(32))

def db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    c.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL, balance INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS bets(
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, stake INTEGER NOT NULL,
        multiplier REAL NOT NULL, payout INTEGER NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL)""")
    c.commit(); return c

def login_required(f):
    @wraps(f)
    def w(*a, **k):
        return f(*a, **k) if "user_id" in session else redirect(url_for("login"))
    return w

@app.route("/")
def index(): return render_template("index.html", user=session.get("username"))

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        u=request.form["username"].strip(); p=request.form["password"]
        if not u or not p: flash("Username and password are required."); return redirect(url_for("register"))
        c=db()
        try:
            c.execute("INSERT INTO users(username,password,created_at) VALUES(?,?,?)",(u,p,datetime.utcnow().isoformat()))
            c.commit(); flash("Account created."); return redirect(url_for("login"))
        except sqlite3.IntegrityError: flash("Username already exists.")
        finally: c.close()
    return render_template("register.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        c=db(); u=c.execute("SELECT * FROM users WHERE username=? AND password=?",(request.form["username"].strip(),request.form["password"])).fetchone(); c.close()
        if u: session["user_id"]=u["id"]; session["username"]=u["username"]; return redirect(url_for("game"))
        flash("Invalid username or password.")
    return render_template("login.html")

@app.route("/logout")
def logout(): session.clear(); return redirect(url_for("index"))

@app.route("/game", methods=["GET","POST"])
@login_required
def game():
    c=db(); u=c.execute("SELECT * FROM users WHERE id=?",(session["user_id"],)).fetchone()
    if request.method=="POST":
        try: stake=int(request.form.get("stake","0")); mult=float(request.form.get("multiplier","1"))
        except ValueError: stake,mult=0,1
        if stake<10: flash("Minimum stake is KSh 10.")
        elif stake>u["balance"]: flash("Insufficient demo balance.")
        elif mult<1: flash("Invalid multiplier.")
        else:
            payout=int(stake*mult)
            c.execute("UPDATE users SET balance=balance-? WHERE id=?",(stake,u["id"]))
            c.execute("INSERT INTO bets(user_id,stake,multiplier,payout,status,created_at) VALUES(?,?,?,?,?,?)",
                      (u["id"],stake,mult,payout,"DEMO",datetime.utcnow().isoformat()))
            c.commit(); flash(f"Demo bet recorded: KSh {stake} at {mult:.2f}x.")
    u=c.execute("SELECT * FROM users WHERE id=?",(session["user_id"],)).fetchone()
    bets=c.execute("SELECT * FROM bets WHERE user_id=? ORDER BY id DESC LIMIT 50",(u["id"],)).fetchall()
    c.close(); return render_template("game.html",user=u,bets=bets)

@app.route("/demo-credit", methods=["POST"])
@login_required
def demo_credit():
    try: amount=int(request.form.get("amount","0"))
    except ValueError: amount=0
    if 0<amount<=100000:
        c=db(); c.execute("UPDATE users SET balance=balance+? WHERE id=?",(amount,session["user_id"])); c.commit(); c.close()
        flash(f"Demo credit of KSh {amount} added.")
    return redirect(url_for("game"))

@app.get("/health")
def health(): return {"status":"ok"}

db().close()
